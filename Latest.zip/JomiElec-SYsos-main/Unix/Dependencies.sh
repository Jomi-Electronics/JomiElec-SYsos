pip3 install numpy
pip3 install termcolor
pip3 install cdifflib
