sudo python3 ../sysos.py
