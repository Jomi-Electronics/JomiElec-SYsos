
## Install Dependencies
### MAC / LINUX
In Mac or linux, run `bash Dependencies.sh`
### WINDOWS
In Windows, double click `Dependencies.bat`

## Usage
In your default CLI of choice, run `bash init.sh` in the sysos directory

## About
The `sysos (experimental).py` contains new features that ***may not be stable, or fully worked out. Please don't expect it to work out of the box!*** If you do encounter any   
issues, do not hesitate to make a bug report.
